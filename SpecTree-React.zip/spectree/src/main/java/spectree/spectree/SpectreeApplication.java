package spectree.spectree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpectreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpectreeApplication.class, args);
	}

}
